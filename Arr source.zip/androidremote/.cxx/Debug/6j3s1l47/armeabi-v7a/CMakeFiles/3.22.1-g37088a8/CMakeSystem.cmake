set(CMAKE_HOST_SYSTEM "Darwin-25.0.0")
set(CMAKE_HOST_SYSTEM_NAME "Darwin")
set(CMAKE_HOST_SYSTEM_VERSION "25.0.0")
set(CMAKE_HOST_SYSTEM_PROCESSOR "arm64")

include("/Users/lapteck/Library/Android/sdk/ndk/27.0.12077973/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "armv7-a")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
